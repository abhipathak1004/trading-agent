"""BharatQuant paper-trading application."""
