"""Persistence for BharatQuant."""
